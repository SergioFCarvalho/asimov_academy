export default function Joke() {
  return (
    <div data-testid="Joke">
      <h3>Setup: {/** SETUP aqui */}</h3>
      <p>Punchline: {/** PUNCHLINE aqui */}</p>
      <hr />
    </div>
  );
}
